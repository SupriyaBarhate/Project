//
//  Product.swift
//  Dishwashers
//
//

import Foundation

class Product: NSObject {
    
    var productID: Int
    var price: Float
    var title: String
    var image: URL
    
    init(ID productID : Int ,productPrice price : Float ,productTitle title:String , productImage image:URL) {
        self.productID = productID
        self.price = price
        self.title=title
        self.image=image
    }
    
}
