//
//  ViewController.swift
//  Dishwasher
//
//

import UIKit
import Alamofire
import SwiftyJSON
import AVFoundation

class ViewController: UIViewController{

    var products = [Product]()
    let identifier = "Cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Dashboard"
        
        
        fetchAllProducts()
    

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // With URLSession
    public func fetchAllProducts() {
        
        let mgr:ServiceManager = ServiceManager.sharedInstance
    
        mgr.fetchProducts({ products in
            
            self.navigationItem.title = "Dishwashers (\(products.count))"
            self.products=products
            self.loadDashBoard()
           
            
        }) { (error) in
            
            
        }

    }
    
    func loadDashBoard() -> Void {
        let storyBoard:UIStoryboard = UIStoryboard(name:"Main", bundle:nil)
        
        let dashBoardViewController:DashboardViewController = storyBoard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
        dashBoardViewController.products=self.products
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.pushViewController(dashBoardViewController, animated: true)
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        self.view.setNeedsDisplay()
    }
    
    
    

}

