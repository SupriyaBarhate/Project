//
//  ServiceManager.swift
//  Dishwasher
//

//

import Foundation


import Alamofire
import SwiftyJSON

enum JSONParsingError: Error {
    case invalidProductID
    case invalidPrice
    case invalidTitle
    case invalidImageURL
    case invalidProductsArray
}

class ServiceManager: NSObject {
    
    static let sharedInstance = ServiceManager()
    
    var baseURL:String
    
    private override init() {
        self.baseURL = "https://api.johnlewis.com/v1/products/search?q=dishwasher&key=Wu1Xqn3vNrd1p7hqkvB6hEu0G9OrsYGb&pageSize=20"
    }
    
    

    func fetchProducts(_ successBlock: @escaping ([Product]) -> Void, failureBlock: @escaping (_ error: Error?) -> Void) {
        
        
        Alamofire.request(self.baseURL).responseJSON { response in
                
                switch response.result {
                    
                case .success:
                    if let json = response.result.value {
                        do {
                            let products = try self.parseProducts(fromJSON: JSON(json))
                            successBlock(products)
                            
                        } catch {
                            
                            failureBlock(NSError(domain: "Could not load products", code: 0, userInfo: nil))
                            
                        }
                    }
                case .failure(let error):
                    
                    failureBlock(error)
                    
                }
        }
    }
    
    
    public func parseSingleProduct(fromJSON json: JSON) throws -> Product {
        
        guard let productIDStr = json["productId"].string,
            let productID = Int(productIDStr) else {
                throw JSONParsingError.invalidProductID
        }
        
        guard let priceStr = json["price"]["now"].string,
            let price = Float(priceStr) else {
                throw JSONParsingError.invalidPrice
        }
        
        guard let title = json["title"].string else {
            throw JSONParsingError.invalidTitle
        }
        
        guard let imageURLStr = json["image"].string,
            let imageURL = URL(string: "https:\(imageURLStr)") else {
                throw JSONParsingError.invalidImageURL
        }
        
        return Product(ID: productID,
                       productPrice: price,
                       productTitle: title,
                       productImage: imageURL)
    }
    
    public func parseProducts(fromJSON json: JSON) throws -> [Product] {
        
        guard let jsonProducts = json["products"].array else {
            throw JSONParsingError.invalidProductsArray
        }
        
        var products = [Product]()
        
        jsonProducts.forEach { (productJSON) in
            
            do {
                try products.append(self.parseSingleProduct(fromJSON: productJSON))
            } catch let error {
                print("Product parse error at index \(jsonProducts.index(of: productJSON)): \(error)")
            }
        }
        
        return products
    }
    
}
