//
//  ViewController.swift
//  Dishwasher
//
//

import UIKit
import AVFoundation
//CollectionViewLayoutDelegate
class DashboardViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var dashboardCollectionView: UICollectionView!
    @IBOutlet weak var floatingButton: UIButton!
    var products = [Product]()

    
    let identifier = "Cell"
    

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Dashboard"

        
//        if let layout = dashboardCollectionView?.collectionViewLayout as? CollectionViewLayout {
//            layout.delegate = self
//        }

        
        self.dashboardCollectionView.register(UINib(nibName:"AddsCollectionViewCell", bundle:nil), forCellWithReuseIdentifier: identifier)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        self.dashboardCollectionView.collectionViewLayout.invalidateLayout()
        self.view.setNeedsDisplay()
    }
    
   
    
    func showAdDetails() -> Void {
//        let storyBoard:UIStoryboard = UIStoryboard(name:"Main", bundle:nil)
//        
//        let adDetailsViewController = storyBoard.instantiateViewController(withIdentifier: "AdDetailsViewController")
//        
//        self.navigationController?.pushViewController(adDetailsViewController, animated: true)
//        
//        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    private func numberOfSectionsInCollectionView(collectionView:
        UICollectionView!) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell:AddsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier,for:indexPath) as! AddsCollectionViewCell
        
        cell.cellTitleLabel.text = products[indexPath.row].title

   
        let imageUrl:NSURL = products[indexPath.row].image as NSURL
        
        let urlString = imageUrl.absoluteString

        
        URLSession.shared.dataTask(with: NSURL(string: urlString!)! as URL, completionHandler: { (data, response, error) -> Void in
            
            if error != nil {
                print(error)
                return
            }
            DispatchQueue.main.async(execute: { () -> Void in
                let image = UIImage(data: data!)
//                self.image = image
                cell.posterImageView.image=image
            })
            
        }).resume()
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.showAdDetails()
    }
    
}

//extension DashboardViewController  {
//    func collectionView(collectionView:UICollectionView, heightForPhotoAtIndexPath indexPath: NSIndexPath,
//                        withWidth width: CGFloat) -> CGFloat {
////        let photo:UIImage! = UIImage(named:carImages[indexPath.item])
//        let size = CGSize(width: 20, height: 30)
//        let boundingRect =  CGRect(x: 0, y: 0, width: width, height: CGFloat(MAXFLOAT))
////        let rect  = AVMakeRect(aspectRatio: photo.size, insideRect: boundingRect)
//        let rect  = AVMakeRect(aspectRatio: size, insideRect: boundingRect)
//        return rect.size.height
//    }
//    
//    // 2
//    func collectionView(collectionView: UICollectionView,
//                        heightForAnnotationAtIndexPath indexPath: NSIndexPath, withWidth width: CGFloat) -> CGFloat {
//        let annotationPadding = CGFloat(4)
//        let annotationHeaderHeight = CGFloat(17)
//        let commentHeight:CGFloat = 0.0
//        let height = annotationPadding + annotationHeaderHeight + commentHeight + annotationPadding
//        return height
//    }
//}






